import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as path from 'path';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import * as cf from 'aws-cdk-lib/aws-cloudfront';
import * as origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as ddb from 'aws-cdk-lib/aws-dynamodb';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import * as apigw from 'aws-cdk-lib/aws-apigatewayv2';
import { WebSocketLambdaIntegration } from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import { WebSocketLambdaAuthorizer } from 'aws-cdk-lib/aws-apigatewayv2-authorizers';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';

export class IslandOfDreadStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    const destroy = cdk.RemovalPolicy.DESTROY; // dev-friendly: `cdk destroy` removes everything

    // S3: game client + lore JSON (private; served only through CloudFront)
    const bucket = new s3.Bucket(this, 'SiteBucket', {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      removalPolicy: destroy,
      autoDeleteObjects: true,
    });

    // CloudFront
    const dist = new cf.Distribution(this, 'Cdn', {
      defaultRootObject: 'index.html',
      defaultBehavior: {
        origin: origins.S3BucketOrigin.withOriginAccessControl(bucket),
        viewerProtocolPolicy: cf.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
      },
    });

    // DynamoDB: all game state
    const stateTable = new ddb.Table(this, 'GameState', {
      partitionKey: { name: 'pk', type: ddb.AttributeType.STRING },
      sortKey: { name: 'sk', type: ddb.AttributeType.STRING },
      billingMode: ddb.BillingMode.PAY_PER_REQUEST,
      removalPolicy: destroy,
    });
    const connTable = new ddb.Table(this, 'Connections', {
      partitionKey: { name: 'connectionId', type: ddb.AttributeType.STRING },
      billingMode: ddb.BillingMode.PAY_PER_REQUEST,
      timeToLiveAttribute: 'ttl',
      removalPolicy: destroy,
    });

    // Cognito: player auth
    const pool = new cognito.UserPool(this, 'Players', {
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      removalPolicy: destroy,
    });
    const client = pool.addClient('WebClient', {
      authFlows: { userSrp: true, userPassword: true },
      generateSecret: false,
    });

    // Lambda (all game logic)
    const common = {
      runtime: lambda.Runtime.NODEJS_20_X,
      memorySize: 256,
      timeout: cdk.Duration.seconds(10),
      bundling: { minify: true },
    };
    const fn = (name: string, file: string, env: Record<string, string>) =>
      new NodejsFunction(this, name, { ...common, entry: path.join(__dirname, '../lambda', file), environment: env });

    const authFn = fn('AuthorizerFn', 'authorizer.ts', { USER_POOL_ID: pool.userPoolId, CLIENT_ID: client.userPoolClientId });
    const connFn = fn('ConnectionFn', 'connection.ts', { CONN_TABLE: connTable.tableName });
    const gameFn = fn('GameFn', 'game.ts', { STATE_TABLE: stateTable.tableName, CONN_TABLE: connTable.tableName, BUCKET: bucket.bucketName });
    connTable.grantReadWriteData(connFn);
    connTable.grantReadData(gameFn);
    stateTable.grantReadWriteData(gameFn);
    bucket.grantRead(gameFn, 'lore/*');

    // API Gateway WebSocket (real-time), JWT checked on $connect via ?token=
    const authorizer = new WebSocketLambdaAuthorizer('JwtAuthorizer', authFn, {
      identitySource: ['route.request.querystring.token'],
    });
    const connInt = new WebSocketLambdaIntegration('ConnInt', connFn);
    const api = new apigw.WebSocketApi(this, 'GameSocket', {
      connectRouteOptions: { integration: connInt, authorizer },
      disconnectRouteOptions: { integration: connInt },
      defaultRouteOptions: { integration: new WebSocketLambdaIntegration('GameInt', gameFn) },
    });
    const stage = new apigw.WebSocketStage(this, 'Prod', { webSocketApi: api, stageName: 'prod', autoDeploy: true });
    api.grantManageConnections(gameFn);

    // EventBridge: night cycles (night <-> dawn), broadcast to connected players
    const nightFn = fn('NightCycleFn', 'nightCycle.ts', {
      STATE_TABLE: stateTable.tableName,
      CONN_TABLE: connTable.tableName,
      WS_ENDPOINT: `https://${api.apiId}.execute-api.${this.region}.amazonaws.com/prod`,
    });
    stateTable.grantReadWriteData(nightFn);
    connTable.grantReadWriteData(nightFn);
    api.grantManageConnections(nightFn);
    const minutes = Number(this.node.tryGetContext('nightMinutes') ?? 2);
    new events.Rule(this, 'NightCycleRule', {
      schedule: events.Schedule.rate(cdk.Duration.minutes(minutes)),
      targets: [new targets.LambdaFunction(nightFn)],
    });

    // Deploy client + runtime config + lore to S3, then invalidate CloudFront
    new s3deploy.BucketDeployment(this, 'DeployClient', {
      sources: [
        s3deploy.Source.asset(path.join(__dirname, '../client')),
        s3deploy.Source.jsonData('config.json', {
          region: this.region,
          userPoolId: pool.userPoolId,
          userPoolClientId: client.userPoolClientId,
          webSocketUrl: stage.url,
          loreUrl: '/lore/lore.json',
        }),
      ],
      destinationBucket: bucket,
      distribution: dist,
      distributionPaths: ['/*'],
      prune: false,
    });
    new s3deploy.BucketDeployment(this, 'DeployLore', {
      sources: [s3deploy.Source.asset(path.join(__dirname, '../lore'))],
      destinationBucket: bucket,
      destinationKeyPrefix: 'lore',
      prune: false,
    });

    new cdk.CfnOutput(this, 'CloudFrontUrl', { value: `https://${dist.distributionDomainName}` });
    new cdk.CfnOutput(this, 'WebSocketUrl', { value: stage.url });
    new cdk.CfnOutput(this, 'UserPoolId', { value: pool.userPoolId });
    new cdk.CfnOutput(this, 'UserPoolClientId', { value: client.userPoolClientId });
  }
}
