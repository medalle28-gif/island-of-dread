import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { ApiGatewayManagementApiClient, PostToConnectionCommand } from '@aws-sdk/client-apigatewaymanagementapi';
import type { APIGatewayProxyWebsocketHandlerV2 } from 'aws-lambda';

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const s3 = new S3Client({});
const { STATE_TABLE, CONN_TABLE, BUCKET } = process.env as Record<string, string>;
const SKIN_WALKERS = ['Wren', 'Otto', 'Pell', 'The Unnamed One'];
const LORE_TOTAL = 56;

type Ending = 'escape' | 'survival' | 'redemption' | 'true' | null;
type PlayerState = { playerId: string; night: number; tamed: string[]; collected: number[]; deaths: number; ending: Ending; updatedAt: number };
const fresh = (playerId: string): PlayerState => ({ playerId, night: 1, tamed: [], collected: [], deaths: 0, ending: null, updatedAt: Date.now() });
let loreCache: unknown;

// Ending rules: Escape = leave before Night 5. After Night 5: True = all 4 tamed + all 56 lore,
// Redemption = at least one tamed, Survival = none tamed.
const finalEnding = (s: PlayerState): Ending =>
  s.tamed.length === SKIN_WALKERS.length && s.collected.length === LORE_TOTAL ? 'true' : s.tamed.length > 0 ? 'redemption' : 'survival';

export const handler: APIGatewayProxyWebsocketHandlerV2 = async (event) => {
  const { connectionId, domainName, stage } = event.requestContext;
  const api = new ApiGatewayManagementApiClient({ endpoint: `https://${domainName}/${stage}` });
  const send = (d: unknown) => api.send(new PostToConnectionCommand({ ConnectionId: connectionId, Data: Buffer.from(JSON.stringify(d)) }));

  const conn = await ddb.send(new GetCommand({ TableName: CONN_TABLE, Key: { connectionId } }));
  const playerId: string | undefined = conn.Item?.playerId;
  if (!playerId) { await send({ type: 'error', message: 'unauthorised' }); return { statusCode: 401 }; }

  let msg: any;
  try { msg = JSON.parse(event.body ?? '{}'); } catch { await send({ type: 'error', message: 'invalid JSON' }); return { statusCode: 400 }; }

  const key = { pk: `PLAYER#${playerId}`, sk: 'STATE' };
  const cur = await ddb.send(new GetCommand({ TableName: STATE_TABLE, Key: key }));
  let s: PlayerState = (cur.Item?.state as PlayerState) ?? fresh(playerId);
  let error: string | undefined;

  if (msg.action === 'getLore') {
    loreCache ??= JSON.parse(await (await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: 'lore/lore.json' }))).Body!.transformToString());
    await send({ type: 'lore', lore: loreCache });
    return { statusCode: 200 };
  }

  if (msg.action === 'reset') s = fresh(playerId);
  else if (s.ending && msg.action !== 'join') error = 'run already finished; send reset to start again';
  else switch (msg.action) {
    case 'join': break;
    case 'collect':
      if (Number.isInteger(msg.id) && msg.id >= 0 && msg.id < LORE_TOTAL) { if (!s.collected.includes(msg.id)) s.collected.push(msg.id); }
      else error = 'invalid lore id';
      break;
    case 'tame':
      if (SKIN_WALKERS.includes(msg.name)) { if (!s.tamed.includes(msg.name)) s.tamed.push(msg.name); }
      else error = 'unknown skin walker';
      break;
    case 'die': s.deaths++; break;
    case 'completeNight':
      if (msg.night !== s.night) error = 'wrong night';
      else if (s.night >= 5) s.ending = finalEnding(s);
      else s.night++;
      break;
    case 'escape':
      if (s.night < 5) s.ending = 'escape'; else error = 'too late to escape';
      break;
    default: error = 'unknown action';
  }

  if (error) { await send({ type: 'error', message: error }); return { statusCode: 400 }; }
  s.updatedAt = Date.now();
  await ddb.send(new PutCommand({ TableName: STATE_TABLE, Item: { ...key, state: s } }));
  const world = await ddb.send(new GetCommand({ TableName: STATE_TABLE, Key: { pk: 'WORLD', sk: 'PHASE' } }));
  await send({ type: 'state', state: s, world: world.Item?.phase ?? { phase: 'night', cycle: 1 } });
  return { statusCode: 200 };
};
