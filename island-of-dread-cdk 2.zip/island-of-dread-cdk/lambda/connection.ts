import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import type { APIGatewayProxyWebsocketEventV2 } from 'aws-lambda';

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TableName = process.env.CONN_TABLE!;

export const handler = async (event: APIGatewayProxyWebsocketEventV2) => {
  const rc: any = event.requestContext;
  if (rc.routeKey === '$connect') {
    await ddb.send(new PutCommand({
      TableName,
      Item: { connectionId: rc.connectionId, playerId: rc.authorizer?.playerId, ttl: Math.floor(Date.now() / 1000) + 7200 },
    }));
  } else {
    await ddb.send(new DeleteCommand({ TableName, Key: { connectionId: rc.connectionId } }));
  }
  return { statusCode: 200 };
};
