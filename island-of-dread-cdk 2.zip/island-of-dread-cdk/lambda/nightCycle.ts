import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand, ScanCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { ApiGatewayManagementApiClient, PostToConnectionCommand } from '@aws-sdk/client-apigatewaymanagementapi';

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const api = new ApiGatewayManagementApiClient({ endpoint: process.env.WS_ENDPOINT });
const { STATE_TABLE, CONN_TABLE } = process.env as Record<string, string>;

// Invoked by EventBridge on a schedule: flips the world between night and dawn and tells every connected player.
export const handler = async () => {
  const key = { pk: 'WORLD', sk: 'PHASE' };
  const cur = (await ddb.send(new GetCommand({ TableName: STATE_TABLE, Key: key }))).Item?.phase ?? { phase: 'dawn', cycle: 0 };
  const next = cur.phase === 'night' ? { phase: 'dawn', cycle: cur.cycle } : { phase: 'night', cycle: cur.cycle + 1 };
  await ddb.send(new PutCommand({ TableName: STATE_TABLE, Item: { ...key, phase: next } }));

  const conns = (await ddb.send(new ScanCommand({ TableName: CONN_TABLE }))).Items ?? [];
  await Promise.all(conns.map(async (c) => {
    try {
      await api.send(new PostToConnectionCommand({ ConnectionId: c.connectionId, Data: Buffer.from(JSON.stringify({ type: 'phase', ...next })) }));
    } catch (e: any) {
      if (e.name === 'GoneException' || e.$metadata?.httpStatusCode === 410)
        await ddb.send(new DeleteCommand({ TableName: CONN_TABLE, Key: { connectionId: c.connectionId } }));
    }
  }));
  return next;
};
