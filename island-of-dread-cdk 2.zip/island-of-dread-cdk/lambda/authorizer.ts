import { CognitoJwtVerifier } from 'aws-jwt-verify';
import type { APIGatewayRequestAuthorizerEvent, APIGatewayAuthorizerResult } from 'aws-lambda';

const verifier = CognitoJwtVerifier.create({
  userPoolId: process.env.USER_POOL_ID!,
  clientId: process.env.CLIENT_ID!,
  tokenUse: 'id',
});

export const handler = async (event: APIGatewayRequestAuthorizerEvent): Promise<APIGatewayAuthorizerResult> => {
  const token = event.queryStringParameters?.token ?? '';
  const policy = (effect: 'Allow' | 'Deny', principalId: string, ctx: Record<string, string> = {}) => ({
    principalId,
    policyDocument: { Version: '2012-10-17', Statement: [{ Action: 'execute-api:Invoke', Effect: effect, Resource: event.methodArn }] },
    context: ctx,
  });
  try {
    const p = await verifier.verify(token);
    return policy('Allow', p.sub, { playerId: p.sub });
  } catch {
    return policy('Deny', 'anonymous');
  }
};
