# Island of Dread: AWS CDK (ap-southeast-2)

Deploys: S3 (client + `lore/lore.json`), CloudFront, DynamoDB (GameState, Connections), Cognito, API Gateway WebSocket,
Lambda (authorizer, connection, game logic, night cycle), EventBridge (night <-> dawn every 2 min; change with `-c nightMinutes=N`).

## Deploy
```
npm install
npx cdk bootstrap aws://ACCOUNT_ID/ap-southeast-2   # once per account/region
npx cdk deploy
```
The `CloudFrontUrl` output is your live URL. `cdk destroy` removes everything.

## WebSocket protocol
Connect to `WebSocketUrl?token=<Cognito ID token>`. Send JSON `{action}`:
`join`, `collect {id 0-55}`, `tame {name}`, `completeNight {night}`, `escape`, `die`, `reset`, `getLore`.
Server replies `{type:'state'|'lore'|'error'}` and broadcasts `{type:'phase', phase, cycle}` on each EventBridge tick.
`config.json` (region, user pool ids, websocket URL) is generated at deploy and served from the site root.

## Notes
- `client/index.html` is the current game. It still runs standalone and does not call the API yet.
- This project was written without running `npm install`/`cdk synth`; run `npm run build` first to catch any typing issues.
